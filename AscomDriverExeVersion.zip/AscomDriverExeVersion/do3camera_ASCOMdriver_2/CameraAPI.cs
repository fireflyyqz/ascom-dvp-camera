// 本文件替代原来的"直接调用 DVP SDK"版本。
// 现在 ASCOM 驱动本身不再引用任何相机 SDK / 原生 DLL（因此可以是 AnyCPU，一份同时给 32/64 位客户端用），
// 所有相机操作都通过 IPC 交给独立的 CameraServer.exe 进程执行：
//   1) 命名管道（Do3CameraServerPipe）发命令、收应答
//   2) 共享内存（Do3CameraServerFrame）取图像帧
//
// 为了尽量少改动 Driver.cs，这里提供与原来 SDK 同名/同 API 的本地类型
// （ImageMatrix / dvpFloatDescr / dvpDoubleDescr / CameraConfig），Driver.cs 里
// 对 cameraConfig.GetGainDescr() / StartSingleExposure() 等的调用都保持不变。

using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.IO.Pipes;
using System.Text;
using System.Threading;

namespace MyCameraAPI
{
    //线程安全的调试日志辅助类：日志失败绝不影响驱动运行
    public static class CameraLog
    {
        private static readonly object sync = new object();

        public static void Write(string msg)
        {
            try
            {
                lock (sync)
                {
                    System.IO.File.AppendAllText(@"C:\temp\camera_debug.txt", msg);
                }
            }
            catch (Exception)
            {
                // 调试日志失败不影响驱动
            }
        }
    }

    #region 与 SDK 同名的本地类型（驱动不再引用 SDK 程序集）

    // 图像矩阵（与原来 SDK 版的字段一致，只保留驱动用到的部分）
    public class ImageMatrix
    {
        public int Width { get; set; }
        public int Height { get; set; }
        public int Channels { get; set; }
        public int BitsPerPixel { get; set; }
        public int[,] Data2D { get; set; }   // [x, y]
    }

    public struct dvpFloatDescr
    {
        public float fMin;
        public float fMax;
        public float fStep;
    }

    public struct dvpDoubleDescr
    {
        public double fMin;
        public double fMax;
        public double fStep;
    }

    // 占位类型：Driver.cs 里还保留着一个未使用的 CameraCapture 字段
    public class CameraCapture { }

    #endregion

    #region IPC 客户端：与 CameraServer.exe 通信

    /// <summary>
    /// 命名管道（命令）+ 共享内存（帧）客户端。
    /// 服务进程未运行时会自动拉起 CameraServer.exe（或 ConsoleApp3.exe）。
    /// </summary>
    internal static class CameraServerClient
    {
        const string PipeName = "Do3CameraServerPipe";
        const string ShmName = "Do3CameraServerFrame";
        const int ShmHeaderBytes = 64;

        static NamedPipeClientStream pipe;
        static StreamReader reader;
        static StreamWriter writer;
        static MemoryMappedFile shm;
        static MemoryMappedViewAccessor shmView;

        static readonly object sync = new object();

        /// <summary>确保服务进程在运行且管道已连接</summary>
        public static void EnsureConnected()
        {
            lock (sync)
            {
                if (pipe != null && pipe.IsConnected && shmView != null) return;

                if (TryConnectPipe()) { OpenShm(); return; }

                StartServer();

                for (int i = 0; i < 50; i++)   // 最多等 ~10 秒
                {
                    Thread.Sleep(200);
                    if (TryConnectPipe()) { OpenShm(); return; }
                }
                throw new Exception("无法连接 CameraServer.exe（管道 " + PipeName + "）");
            }
        }

        static bool TryConnectPipe()
        {
            try
            {
                var p = new NamedPipeClientStream(".", PipeName, PipeDirection.InOut);
                p.Connect(500);
                pipe = p;
                reader = new StreamReader(p, Encoding.ASCII);
                writer = new StreamWriter(p, Encoding.ASCII) { AutoFlush = true };
                return true;
            }
            catch (Exception)
            {
                try { if (pipe != null) pipe.Dispose(); } catch (Exception) { }
                pipe = null; reader = null; writer = null;
                return false;
            }
        }

        static void OpenShm()
        {
            if (shmView != null) return;
            shm = MemoryMappedFile.OpenExisting(ShmName);
            shmView = shm.CreateViewAccessor(0, 0);
        }

        static void StartServer()
        {
            string dir = Path.GetDirectoryName(typeof(CameraServerClient).Assembly.Location);
            string exe = Path.Combine(dir, "CameraServer.exe");
            if (!File.Exists(exe)) exe = Path.Combine(dir, "ConsoleApp3.exe");   // 兼容旧名
            if (!File.Exists(exe)) throw new Exception("找不到 CameraServer.exe: " + exe);

            var psi = new ProcessStartInfo(exe) { WorkingDirectory = dir, UseShellExecute = false, CreateNoWindow = true };
            Process.Start(psi);
        }

        static void Close()
        {
            try { if (pipe != null) pipe.Dispose(); } catch (Exception) { }
            pipe = null; reader = null; writer = null;
        }

        // 发一条命令、收一条应答（文本行协议）
        static string Send(string cmd)
        {
            EnsureConnected();
            lock (sync)
            {
                writer.WriteLine(cmd);
                string reply = reader.ReadLine();
                if (reply == null) { Close(); throw new Exception("CameraServer 连接已断开"); }
                return reply;
            }
        }

        // ---------------- 高层命令 ----------------
        public static bool Connect() { return Send("CONNECT").StartsWith("OK"); }

        public static bool Disconnect()
        {
            try { Send("DISCONNECT"); } catch (Exception) { }
            Close();
            return true;
        }

        public static bool SetBin(int bin) { return Send("SETBIN " + bin.ToString(CultureInfo.InvariantCulture)).StartsWith("OK"); }

        public static bool SetGainRaw(float raw) { return Send("SETGAIN " + raw.ToString(CultureInfo.InvariantCulture)).StartsWith("OK"); }

        public static bool StartExposure(int us) { return Send("EXPOSE " + us.ToString(CultureInfo.InvariantCulture)).StartsWith("OK"); }

        public static bool Abort() { return Send("ABORT").StartsWith("OK"); }

        public static bool Ready() { return Send("READY") == "1"; }

        public static void GetGainDescr(out double min, out double step, out double max)
        {
            string[] r = Send("GETGAINDESCR").Split(' ');
            min = double.Parse(r[1], CultureInfo.InvariantCulture);
            step = double.Parse(r[2], CultureInfo.InvariantCulture);
            max = double.Parse(r[3], CultureInfo.InvariantCulture);
        }

        public static void GetExpDescr(out double min, out double step, out double max)
        {
            string[] r = Send("GETEXPDESCR").Split(' ');
            min = double.Parse(r[1], CultureInfo.InvariantCulture);
            step = double.Parse(r[2], CultureInfo.InvariantCulture);
            max = double.Parse(r[3], CultureInfo.InvariantCulture);
        }

        // 取帧：返回 int[w, h]（[x, y]）
        public static int[,] GetFrame(out int w, out int h)
        {
            string[] r = Send("GETFRAME").Split(' ');
            w = int.Parse(r[1], CultureInfo.InvariantCulture);
            h = int.Parse(r[2], CultureInfo.InvariantCulture);

            int[] flat = new int[w * h];
            lock (sync)
            {
                shmView.ReadArray(ShmHeaderBytes, flat, 0, flat.Length);
            }

            int[,] data = new int[w, h];
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                    data[x, y] = flat[y * w + x];
            return data;
        }
    }

    #endregion

    #region 与旧 CameraConfig 同 API 的代理（内部走 IPC）

    /// <summary>
    /// 保持与原来"直接调 SDK"的 CameraConfig 相同的方法名和返回类型，
    /// Driver.cs 里的调用（GetGainDescr / GetExposureDescr / SetGain / StartSingleExposure …）无需改动。
    /// </summary>
    public class CameraConfig
    {
        public bool stopexposure = false;

        private double lastExposureUs = 1000000;
        private float lastGainRaw = 0;

        public CameraConfig(uint dummyHandle) { }

        public bool DefaultConfig() { return true; }
        public bool SetSourceFormatSel(uint v) { return true; }
        public bool SetTargetFormatSel(uint v) { return true; }
        public bool SetExposureTime(double exposureUs) { lastExposureUs = exposureUs; return true; }
        public bool CloseExposure() { return true; }

        // 分辨率模式索引 0=bin1, 1=bin2 —— 换算成 bin 值发给服务端
        public bool SetResolutionModeSel(uint mode) { return CameraServerClient.SetBin(mode == 1 ? 2 : 1); }

        public dvpFloatDescr GetGainDescr()
        {
            double mn, st, mx;
            CameraServerClient.GetGainDescr(out mn, out st, out mx);
            return new dvpFloatDescr { fMin = (float)mn, fStep = (float)st, fMax = (float)mx };
        }

        public float GetGain() { return lastGainRaw; }

        public bool SetGain(float raw)
        {
            lastGainRaw = raw;
            return CameraServerClient.SetGainRaw(raw);
        }

        public dvpDoubleDescr GetExposureDescr()
        {
            double mn, st, mx;
            CameraServerClient.GetExpDescr(out mn, out st, out mx);
            return new dvpDoubleDescr { fMin = mn, fStep = st, fMax = mx };
        }

        public ImageMatrix StartSingleExposure(double exposureSeconds) { return DoExposure(exposureSeconds); }
        public ImageMatrix StartMultiExposure(double exposureSeconds) { return DoExposure(exposureSeconds); }

        // 发起曝光并等待出图（在专用相机线程上执行，阻塞是允许的）
        private ImageMatrix DoExposure(double exposureSeconds)
        {
            int us = (int)Math.Round(exposureSeconds * 1000000.0);
            CameraServerClient.StartExposure(us);

            // 等待时长必须覆盖完整曝光：多重曝光是"多帧30s累加"，实际耗时不小于标称时长，
            // 所以按 曝光时长 + 60 秒余量 来等。原来固定 120 秒上限会导致 >120s 的曝光
            //（如 300s）在这里提前超时返回 null —— 客户端进度到 100% 却拿不到图。
            int maxLoops = (int)(exposureSeconds * 10.0) + 600;   // 每 loop = 100ms
            for (int i = 0; i < maxLoops; i++)
            {
                if (stopexposure)
                {
                    CameraServerClient.Abort();
                    return null;
                }
                if (CameraServerClient.Ready()) break;
                Thread.Sleep(100);
            }

            if (!CameraServerClient.Ready()) return null;

            int w, h;
            int[,] data = CameraServerClient.GetFrame(out w, out h);
            return new ImageMatrix { Width = w, Height = h, Channels = 1, BitsPerPixel = 16, Data2D = data };
        }
    }

    #endregion
}
