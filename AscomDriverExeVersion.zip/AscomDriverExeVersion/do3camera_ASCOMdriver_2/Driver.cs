﻿// All lines from line 1 to the device interface implementation region will be discarded by the project wizard when the template is used
// Required code must lie within the device implementation region
// The //ENDOFINSERTEDFILE tag must be the last but one line in this file

using ASCOM;
using ASCOM.Astrometry.AstroUtils;
using ASCOM.DeviceInterface;
using ASCOM.MyCamera;
using ASCOM.Utilities;
using MyCameraAPI;
using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
[ComVisible(true)]
[Guid("77CBB929-E70F-D7BF-C784-1F93F1C40EF4")]
[ClassInterface(ClassInterfaceType.None)]
[ProgId("ASCOM.Do3Camera.Camera")]
public class DeviceCamera:ICameraV4
{
    /// <summary>
    /// 注册驱动到 ASCOM 平台
    /// </summary>
    [ComRegisterFunction]
    public static void RegisterASCOM(Type t)
    {
        using (var profile = new ASCOM.Utilities.Profile())
        {
            profile.DeviceType = "Camera";
            profile.Register("ASCOM.Do3Camera.Camera", "Do3Camera");
        }
    }

    /// <summary>
    /// 从 ASCOM 平台卸载驱动
    /// </summary>
    [ComUnregisterFunction]
    public static void UnregisterASCOM(Type t)
    {
        using (var profile = new ASCOM.Utilities.Profile())
        {
            profile.DeviceType = "Camera";
            profile.Unregister("ASCOM.Do3Camera.Camera");
        }
    }

    Util util = new Util();
    TraceLogger tl = new TraceLogger();

    #region ICamera Implementation

    private const int ccdWidth = 4000; // Constants to define the CCD pixel dimensions
    private const int ccdHeight = 3000;
    private const double pixelSize = 1.85; // Constant for the pixel physical dimension

    private int cameraNumX = ccdWidth; // Initialise variables to hold values required for functionality tested by Conform
    private int cameraNumY = ccdHeight;
    private int cameraStartX = 0;
    private int cameraStartY = 0;
    private DateTime exposureStart = DateTime.MinValue;
    private double cameraLastExposureDuration = 1.0;
    private bool cameraImageReady = false;
    private int[,] cameraImageArray;
    private object[,] cameraImageArrayVariant;
    int[,] currentImageArray;
    //-----------------------------
    uint cameraHandle;
    public bool IsOnline = false;
    public CameraConfig cameraConfig;
    private CameraCapture camera = new CameraCapture();//图像缓存读取容器
    string cameraName = "M3S1201M@U002000000258";//相机参数配置
    short binmode = 1;//normal模式
    CameraStates cameraState= CameraStates.cameraError;
    short currentPercent = 0;


    //---------------------
    internal static string driverID = "ASCOM.Do3Camera.Camera";
    private static string driverDescription = "ASCOM Camera Driver for MyCamera.";
    internal static string comPortProfileName = "COM Port"; // Constants used for Profile persistence
    internal static string comPortDefault = "COM2";
    internal static string traceStateProfileName = "Trace Level";
    internal static string traceStateDefault = "false";
    internal static string comPort; // Variables to hold the current device configuration
    private bool connectedState;
    private Util utilities;
    private AstroUtils astroUtilities;
    public ImageMatrix currentFrame=null;
    private readonly object imageLock = new object();//后台采集线程与轮询线程之间的锁
    private bool captureDone = false;//后台采集线程完成标志
    private long exposureGeneration = 0;//曝光代次，用于丢弃过期采集结果

    // 专用 STA 相机线程：所有 DVP SDK 调用都在它上面执行，满足 SDK 的"同一线程/STA"要求
    private Thread cameraThread = null;
    private BlockingCollection<Action> cameraQueue = null;


    public DeviceCamera()
    {
        tl = new TraceLogger("", "MyCamera");
        ReadProfile();
        tl.LogMessage("MyCamera", "Starting initialisation");
        connectedState = false;
        utilities = new Util();
        astroUtilities = new AstroUtils();
        tl.LogMessage("MyCamera", "Completed initialisation");
    }

    //获取ms级时间戳
    public static Int64 GetTimeStamp()
    {
        TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
        var ret = Convert.ToInt64(ts.TotalMilliseconds); // 毫秒级时间戳
        return ret;
    }
    Int64 lastTimeStamp = GetTimeStamp();

    //启动专用 STA 相机线程（懒加载）。所有 DVP SDK 调用都在它上面执行，
    //满足 SDK 的"refresh/open/start 同一线程"以及可能的 STA/apartment 要求。
    private void EnsureCameraThread()
    {
        if (cameraThread != null) return;
        cameraQueue = new BlockingCollection<Action>();
        cameraThread = new Thread(() =>
        {
            foreach (Action action in cameraQueue.GetConsumingEnumerable())
            {
                try { action(); }
                catch (Exception ex) { CameraLog.Write($"{DateTime.Now}: CameraThread ERROR {ex} callback\n"); }
            }
        });
        cameraThread.SetApartmentState(ApartmentState.STA);
        cameraThread.IsBackground = true;
        cameraThread.Name = "DVP_CameraThread";
        cameraThread.Start();
    }

    //在相机线程上执行并等待结果（所有 SDK 调用走这里）
    private T RunOnCameraThread<T>(Func<T> func)
    {
        EnsureCameraThread();
        T result = default(T);
        Exception error = null;
        using (var done = new ManualResetEventSlim(false))
        {
            cameraQueue.Add(() =>
            {
                try { result = func(); }
                catch (Exception ex) { error = ex; }
                finally { done.Set(); }
            });
            done.Wait();
        }
        if (error != null) throw error;
        return result;
    }

    //投递到相机线程异步执行（不等待，用于采集）
    private void PostToCameraThread(Action action)
    {
        EnsureCameraThread();
        cameraQueue.Add(action);
    }

    //公共入口：把连接/断开投递到专用 STA 相机线程执行（所有 SDK 调用都在那条线程上）
    public bool ConnectCamera(bool connect)
    {
        return RunOnCameraThread(() => ConnectCameraInternal(connect));
    }

    private bool ConnectCameraInternal(bool connect)
    {
        if (connect)
        {
            try
            {
                CameraLog.Write($"{DateTime.Now}: ConnectCamera callback\n");

                // 通过 IPC 让独立的 CameraServer.exe 打开相机（SDK 不再运行在客户端进程里）
                CameraServerClient.EnsureConnected();   // 服务未运行会自动拉起
                bool ok = CameraServerClient.Connect();
                CameraLog.Write($"{DateTime.Now}: CameraServer connect ok={ok} callback\n");
                if (!ok)
                {
                    connectedState = false;
                    IsOnline = false;
                    throw new ASCOM.NotConnectedException("相机服务连接失败（CameraServer.exe）");
                }

                cameraConfig = new CameraConfig(0);     // IPC 代理
                cameraConfig.SetExposureTime(1000000);//设置曝光时间为1s
                cameraState = CameraStates.cameraIdle;
                IsOnline = true;
                connectedState = true;
                return true;
            }
            catch (Exception)
            {
                // 重新抛出，避免把 NotConnectedException 等吞掉导致 PHD2 误以为连接成功
                throw;
            }   
        }
        else
        {
            try
            {
                CameraServerClient.Disconnect();
                cameraState = CameraStates.cameraError;
                IsOnline = false;
                connectedState=false;
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }

    public bool CheckConnection()
    {
        // 连接状态由相机线程维护，客户端只读，不直接调用 SDK（保证所有 SDK 调用都在相机线程上）
        IsOnline = connectedState;
        return connectedState;
    }

    public void AbortExposure()
    {
        cameraImageReady = false;
        IsOnline = CheckConnection();
        if (!IsOnline)
        {
            tl.LogMessage("AbortExposure", "disconnected");
            cameraState = CameraStates.cameraError;
            throw new ASCOM.NotConnectedException("AbortExposure");
        }
        try
        {
            // 先置标志（非 SDK 调用）让采集循环尽快退出；停流是 SDK 调用，投递到相机线程执行
            if (cameraConfig != null) cameraConfig.stopexposure = true;
            PostToCameraThread(() => { if (cameraConfig != null) cameraConfig.CloseExposure(); });
            // 清除待处理的采集结果，避免残留帧被下次曝光读到
            lock (imageLock)
            {
                currentFrame = null;
                captureDone = false;
            }
            cameraState = CameraStates.cameraIdle;
        }
        catch (Exception)
        {
            tl.LogMessage("AbortExposure", "error");
            throw new ASCOM.DriverException("AbortExposure error");
        }

    }

    public short BayerOffsetX
    {
        get
        {
            return 0;
        }
    }

    public short BayerOffsetY
    {
        get
        {
            return 0;
        }
    }

    public short BinX
    {
        get
        {
            tl.LogMessage("BinX Get", "1");
            return binmode;
        }
        set
        {
            tl.LogMessage("BinX Set", value.ToString());
            switch (value)//0 - 6范围，对应normal bin2 sum2 bin3 sum3 bin4 sum4
            {
                case 1://bin1
                    binmode = 1;
                    try { cameraConfig.SetResolutionModeSel(0); }
                    catch (Exception) { }
                    break;
                case 2://bin2
                    binmode = 2;
                    try { cameraConfig.SetResolutionModeSel(1); }
                    catch (Exception) { }
                    break;
                default:
                    throw new ASCOM.InvalidValueException("BinX", value.ToString(), "out of range:1, 2, 3, 4");
            }
        }
    }

    public short BinY
    {
        get
        {
            tl.LogMessage("BinY Get", "1");
            return binmode;
        }
        set
        {
            tl.LogMessage("BinY Set", value.ToString());
            if (value!=binmode)
            {
                switch (value)//0 - 1范围，对应normal bin2
                {
                    case 1://bin1
                        binmode = 1;
                        try { cameraConfig.SetResolutionModeSel(0); }
                        catch (Exception) {  }
                        break;
                    case 2://bin2
                        binmode = 2;
                        try { cameraConfig.SetResolutionModeSel(1); }
                        catch (Exception) {  }
                        break;
                    default:
                        throw new ASCOM.InvalidValueException("BinY", value.ToString(), "out of range:1, 2, 3, 4");
                }
            }
        }
    }

    public double CCDTemperature
    {
        get
        {
            tl.LogMessage("CCDTemperature Get", "not implemented");
            return 20.0;
        }
    }

    public CameraStates CameraState
    {
        get
        {
            tl.LogMessage("CameraState Get", cameraState.ToString());
            return cameraState;
        }
    }

    public int CameraXSize
    {
        get
        {
            tl.LogMessage("CameraXSize Get", ccdWidth.ToString());
            return ccdWidth;
        }
    }

    public int CameraYSize
    {
        get
        {
            tl.LogMessage("CameraYSize Get", ccdHeight.ToString());
            return ccdHeight;
        }
    }

    //停止曝光，丢弃当前图像数据
    public bool CanAbortExposure
    {
        get
        {
            tl.LogMessage("CanAbortExposure Get", true.ToString());
            return false;
        }
    }
    //非对称binning
    public bool CanAsymmetricBin
    {
        get
        {
            tl.LogMessage("CanAsymmetricBin Get", false.ToString());
            return false;
        }
    }

    public bool CanFastReadout
    {
        get
        {
            tl.LogMessage("CanFastReadout Get", false.ToString());
            return false;
        }
    }

    public bool CanGetCoolerPower
    {
        get
        {
            tl.LogMessage("CanGetCoolerPower Get", false.ToString());
            return false;
        }
    }

    public bool CanPulseGuide
    {
        get
        {
            tl.LogMessage("CanPulseGuide Get", false.ToString());
            return false;
        }
    }

    public bool CanSetCCDTemperature
    {
        get
        {
            tl.LogMessage("CanSetCCDTemperature Get", false.ToString());
            return false;
        }
    }

    public bool CanStopExposure
    {
        get
        {
            tl.LogMessage("CanStopExposure Get", false.ToString());
            return false;
        }
    }

    public bool CoolerOn
    {
        get
        {
            tl.LogMessage("CoolerOn Get", "Not implemented");
            throw new ASCOM.PropertyNotImplementedException("CoolerOn", false);
        }
        set
        {
            tl.LogMessage("CoolerOn Set", "Not implemented");
            throw new ASCOM.PropertyNotImplementedException("CoolerOn", true);
        }
    }

    public double CoolerPower
    {
        get
        {
            tl.LogMessage("CoolerPower Get", "Not implemented");
            throw new ASCOM.PropertyNotImplementedException("CoolerPower", false);
        }
    }

    public double ElectronsPerADU
    {
        get
        {
            tl.LogMessage("ElectronsPerADU Get", "implemented");
            return 1.0;
        }
    }

    public double ExposureMax
    {
        get
        {
            IsOnline = CheckConnection();
            if (!IsOnline)
            {
                tl.LogMessage("ExposureMax Get", "disconnected");
                cameraState = CameraStates.cameraError;
                throw new ASCOM.PropertyNotImplementedException("ExposureMax", false);
            }
            dvpDoubleDescr exposureDescr = cameraConfig.GetExposureDescr();
            tl.LogMessage("ExposureMax Get", "implemented");

            //return (exposureDescr.fMax)/1000000.0;
            return 1200;
        }
    }

    public double ExposureMin
    {
        get
        {
            IsOnline = CheckConnection();
            if (!IsOnline)
            {
                tl.LogMessage("ExposureMin Get", "disconnected");
                cameraState = CameraStates.cameraError;
                throw new ASCOM.PropertyNotImplementedException("ExposureMin", false);
            }
            dvpDoubleDescr exposureDescr = cameraConfig.GetExposureDescr();
            tl.LogMessage("ExposureMin Get", "implemented");
            return exposureDescr.fMin/1000000.0;
        }
    }

    public double ExposureResolution
    {
        get
        {
            IsOnline = CheckConnection();
            if (!IsOnline)
            {
                tl.LogMessage("ExposureResolution Get", "disconnected");
                cameraState = CameraStates.cameraError;
                throw new ASCOM.PropertyNotImplementedException("ExposureResolution", false);
            }
            dvpDoubleDescr exposureDescr = cameraConfig.GetExposureDescr();
            tl.LogMessage("ExposureResolution Get", "implemented");
            return exposureDescr.fStep / 1000000.0;
        }
    }

    public bool FastReadout
    {
        get
        {
            tl.LogMessage("FastReadout Get", "Not implemented");
            throw new ASCOM.PropertyNotImplementedException("FastReadout", false);
        }
        set
        {
            tl.LogMessage("FastReadout Set", "Not implemented");
            throw new ASCOM.PropertyNotImplementedException("FastReadout", true);
        }
    }

    public double FullWellCapacity
    {
        get
        {
            tl.LogMessage("FullWellCapacity Get", "Not implemented");
            throw new ASCOM.PropertyNotImplementedException("FullWellCapacity", false);
        }
    }

    public short Gain
    {
        get
        {
            IsOnline = CheckConnection();
            if (!IsOnline)
            {
                tl.LogMessage("Gain Get", "disconnected");
                cameraState = CameraStates.cameraError;
                throw new ASCOM.PropertyNotImplementedException("Gain", false);
            }
            dvpFloatDescr gainDescr = cameraConfig.GetGainDescr();
            float rawGain=(cameraConfig.GetGain()-gainDescr.fMin) / gainDescr.fStep;
            tl.LogMessage("Gain Get", "implemented");
            return (short)rawGain;

        }
        set
        {
            IsOnline = CheckConnection();
            if (!IsOnline)
            {
                tl.LogMessage("Gain Set", "disconnected");
                cameraState = CameraStates.cameraError;
                throw new ASCOM.PropertyNotImplementedException("Gain", false);
            }
            dvpFloatDescr gainDescr = cameraConfig.GetGainDescr();
            float gainVal = ((float)value)* gainDescr.fStep+ gainDescr.fMin;
            cameraConfig.SetGain(gainVal);
            tl.LogMessage("Gain Set", "implemented");
        }
    }

    public short GainMax
    {
        get
        {
            IsOnline = CheckConnection();
            if (!IsOnline) {
                tl.LogMessage("GainMax Get", "disconnected");
                cameraState = CameraStates.cameraError;
                throw new ASCOM.PropertyNotImplementedException("GainMax", false);
            }
            dvpFloatDescr gainDescr = cameraConfig.GetGainDescr();
            var gainmax= (gainDescr.fMax-gainDescr.fMin)/gainDescr.fStep;
            tl.LogMessage("GainMax Get", "not implemented");
            //throw new ASCOM.PropertyNotImplementedException("GainMax", false);
            return (short)gainmax;
        }
    }

    public short GainMin
    {
        get
        {
            IsOnline = CheckConnection();
            if (!IsOnline)
            {
                tl.LogMessage("GainMin Get", "disconnected");
                cameraState = CameraStates.cameraError;
                throw new ASCOM.PropertyNotImplementedException("GainMin", false);
            }
            tl.LogMessage("GainMin Get", "not implemented");
            //throw new ASCOM.PropertyNotImplementedException("GainMin", false);
            return 0;
        }
    }

    public ArrayList Gains
    {
        get
        {
            //tl.LogMessage("Gains Get", "implemented");
            //throw new ASCOM.PropertyNotImplementedException("Gains", false);
            IsOnline = CheckConnection();
            if (!IsOnline)
            {
                tl.LogMessage("Gains Get", "disconnected");
                cameraState = CameraStates.cameraError;
                throw new ASCOM.PropertyNotImplementedException("Gains", false);
            }
            dvpFloatDescr gainDescr = cameraConfig.GetGainDescr();
            ArrayList gainsList = new ArrayList();
            for (int gain = 0; gain <= (int)(gainDescr.fMax- gainDescr .fMin)/gainDescr.fStep; gain += 1)
            {
                gainsList.Add(gain.ToString());
            }
            tl.LogMessage("Gains Get", "implemented");
            return gainsList;
        }
    }

    public bool HasShutter
    {
        get
        {
            tl.LogMessage("HasShutter Get", false.ToString());
            return false;
        }
    }

    public double HeatSinkTemperature
    {
        get
        {
            tl.LogMessage("HeatSinkTemperature Get", "Not implemented");
            throw new ASCOM.PropertyNotImplementedException("HeatSinkTemperature", false);
        }
    }

    public object ImageArray
    {
        get
        {
            if (!cameraImageReady)
            {
                tl.LogMessage("ImageArray Get", "Throwing InvalidOperationException because of a call to ImageArray before the first image has been taken!");
                throw new ASCOM.InvalidOperationException("Call to ImageArray before the first image has been taken!");
            }
            // 直接返回当前帧数据引用；图像数组已在 CameraCapture 里复用（不再每帧分配），此处无需再强制 GC
            cameraImageArray = currentImageArray;
            cameraState = CameraStates.cameraIdle;
            cameraImageReady = false;
            currentImageArray = null;
            return cameraImageArray;
        }
    }

    public object ImageArrayVariant
    {
        get
        {
            if (!cameraImageReady)
            {
                tl.LogMessage("ImageArrayVariant Get", "Throwing InvalidOperationException because of a call to ImageArrayVariant before the first image has been taken!");
                throw new ASCOM.InvalidOperationException("Call to ImageArrayVariant before the first image has been taken!");
            }
            cameraImageArrayVariant = new object[cameraNumX, cameraNumY];
            for (int i = 0; i < cameraImageArray.GetLength(1); i++)
            {
                for (int j = 0; j < cameraImageArray.GetLength(0); j++)
                {
                    cameraImageArrayVariant[j, i] = cameraImageArray[j, i];
                }
            }
            return cameraImageArrayVariant;
        }
    }

    public bool ImageReady
    {
        get
        {
            // 诊断日志：每次轮询都记录，无论是否在曝光中，以便确认 PHD2 轮询行为和驱动状态
            if ((cameraState == CameraStates.cameraWaiting)&&!cameraImageReady)
            {
                // 防止 lastTimeStamp 未初始化或曝光时长为0时除零/溢出
                double elapsedMs = GetTimeStamp() - lastTimeStamp;
                double totalMs = Math.Max(cameraLastExposureDuration * 1000, 1);
                short currentPercent = (short)Math.Max(0, Math.Min(100, (100.0 * elapsedMs) / totalMs));
                if (currentPercent >= 100)
                {
                    lock (imageLock)
                    {
                        // 先判空再解引用，避免后台采集尚未完成（currentFrame 仍为 null）时轮询线程抛 NullReferenceException
                        if (captureDone && currentFrame != null && currentFrame.Data2D != null)
                        {
                            // 直接引用当前帧数据，不额外分配大数组（原 new int[..] 是死代码，且会在32位进程里触发 OOM）
                            currentImageArray = currentFrame.Data2D;
                            cameraState = CameraStates.cameraReading;
                            currentFrame = null;
                            captureDone = false;
                            cameraImageReady = true;
                            try
                            {
                                StopExposure();
                            }
                            catch (Exception)
                            {
                                // 轮询阶段不因 StopExposure 失败而抛异常，避免 PHD2 轮询崩溃
                            }
                        }
                        else
                        {
                            // 时间已到但帧未就绪，记录原因
                        }
                    }
                }
            }
            tl.LogMessage("ImageReady Get", cameraImageReady.ToString());
            return cameraImageReady;
        }
    }

    public bool IsPulseGuiding
    {
        get
        {
            tl.LogMessage("IsPulseGuiding Get", "Not implemented");
            throw new ASCOM.PropertyNotImplementedException("IsPulseGuiding", false);
        }
    }

    public double LastExposureDuration
    {
        get
        {
            if (!cameraImageReady)
            {
                tl.LogMessage("LastExposureDuration Get", "Throwing InvalidOperationException because of a call to LastExposureDuration before the first image has been taken!");
                throw new ASCOM.InvalidOperationException("Call to LastExposureDuration before the first image has been taken!");
            }
            tl.LogMessage("LastExposureDuration Get", cameraLastExposureDuration.ToString());
            return cameraLastExposureDuration;
        }
    }

    public string LastExposureStartTime
    {
        get
        {
            if (!cameraImageReady)
            {
                tl.LogMessage("LastExposureStartTime Get", "Throwing InvalidOperationException because of a call to LastExposureStartTime before the first image has been taken!");
                throw new ASCOM.InvalidOperationException("Call to LastExposureStartTime before the first image has been taken!");
            }
            string exposureStartString = exposureStart.ToString("yyyy-MM-ddTHH:mm:ss");
            tl.LogMessage("LastExposureStartTime Get", exposureStartString.ToString());
            return exposureStartString;
        }
    }

    public int MaxADU
    {
        get
        {
            tl.LogMessage("MaxADU Get", "65535");
            return 65535;
        }
    }

    public short MaxBinX
    {
        get
        {
            tl.LogMessage("MaxBinX Get", "1");
            return 2;
        }
    }

    public short MaxBinY
    {
        get
        {
            tl.LogMessage("MaxBinY Get", "1");
            return 2;
        }
    }

    public int NumX
    {
        get
        {
            switch (binmode)
            {
                case 1:
                    cameraNumX = ccdWidth;
                    break;
                case 2:
                    cameraNumX = ccdWidth / 2;
                    break;
            }
            tl.LogMessage("NumX Get", cameraNumX.ToString());
            return cameraNumX;
        }
        set
        {
            // 仅支持全画幅宽度（随 bin 变化），合法的全画幅值直接接受，非法值才抛异常
            int legalWidth = (binmode == 2) ? ccdWidth / 2 : ccdWidth;
            if (value != legalWidth)
                throw new ASCOM.InvalidValueException("NumX", value.ToString(), legalWidth.ToString());
            cameraNumX = value;
            tl.LogMessage("NumX set", value.ToString());
        }
    }

    public int NumY
    {
        get
        {
            switch (binmode)
            {
                case 1:
                    cameraNumY = ccdHeight;
                    break;
                case 2:
                    cameraNumY = ccdHeight / 2;
                    break;
            }
            tl.LogMessage("NumY Get", cameraNumY.ToString());
            return cameraNumY;
        }
        set
        {
            // 仅支持全画幅高度（随 bin 变化），合法的全画幅值直接接受，非法值才抛异常
            int legalHeight = (binmode == 2) ? ccdHeight / 2 : ccdHeight;
            if (value != legalHeight)
                throw new ASCOM.InvalidValueException("NumY", value.ToString(), legalHeight.ToString());
            cameraNumY = value;
            tl.LogMessage("NumY set", value.ToString());
        }
    }

    public int Offset
    {
        get
        {
            tl.LogMessage("Offset Get", "Not implemented");
            throw new ASCOM.PropertyNotImplementedException("Offset", false);
        }
        set
        {
            tl.LogMessage("Offset Set", "Not implemented");
            throw new ASCOM.PropertyNotImplementedException("Offset", true);
        }
    }

    public int OffsetMax
    {
        get
        {
            tl.LogMessage("OffsetMax Get", "Not implemented");
            throw new ASCOM.PropertyNotImplementedException("OffsetMax", false);
        }
    }

    public int OffsetMin
    {
        get
        {
            tl.LogMessage("OffsetMin Get", "Not implemented");
            throw new ASCOM.PropertyNotImplementedException("OffsetMin", true);
        }
    }

    public ArrayList Offsets
    {
        get
        {
            tl.LogMessage("Offsets Get", "Not implemented");
            throw new ASCOM.PropertyNotImplementedException("Offsets", true);
        }
    }

    public short PercentCompleted
    {
        get
        {
            // 防止未开始曝光（lastTimeStamp 默认0）或时长为0时产生负数/溢出
            double elapsedMs = GetTimeStamp() - lastTimeStamp;
            double totalMs = Math.Max(cameraLastExposureDuration * 1000, 1);
            short Percent = (short)Math.Max(0, Math.Min(100, (100.0 * elapsedMs) / totalMs));

            tl.LogMessage("PercentCompleted Get", "implemented");

            return Percent;
        }
    }

    public double PixelSizeX
    {
        get
        {
            tl.LogMessage("PixelSizeX Get", pixelSize.ToString());
            return pixelSize;
        }
    }

    public double PixelSizeY
    {
        get
        {
            tl.LogMessage("PixelSizeY Get", pixelSize.ToString());
            return pixelSize;
        }
    }

    public void PulseGuide(GuideDirections Direction, int Duration)
    {
        tl.LogMessage("PulseGuide", "Not implemented");
        throw new ASCOM.MethodNotImplementedException("PulseGuide");
    }

    public short ReadoutMode
    {
        get
        {
            tl.LogMessage("ReadoutMode Get", "Not implemented");
            throw new ASCOM.PropertyNotImplementedException("ReadoutMode", false);
        }
        set
        {
            tl.LogMessage("ReadoutMode Set", "Not implemented");
            throw new ASCOM.PropertyNotImplementedException("ReadoutMode", true);
        }
    }

    public ArrayList ReadoutModes
    {
        get
        {
            tl.LogMessage("ReadoutModes Get", "Not implemented");
            throw new ASCOM.PropertyNotImplementedException("ReadoutModes", false);
        }
    }

    public string SensorName
    {
        get
        {
            tl.LogMessage("SensorName Get", "Not implemented");
            return "unknown cmos";
        }
    }

    public SensorType SensorType
    {
        get
        {
            tl.LogMessage("SensorType Get", "implemented");
            return SensorType.Monochrome;
        }
    }

    public double SetCCDTemperature
    {
        get
        {
            tl.LogMessage("SetCCDTemperature Get", "Not implemented");
            throw new ASCOM.PropertyNotImplementedException("SetCCDTemperature", false);
        }
        set
        {
            tl.LogMessage("SetCCDTemperature Set", "Not implemented");
            throw new ASCOM.PropertyNotImplementedException("SetCCDTemperature", true);
        }
    }

    public void StartExposure(double Duration, bool Light)
    {
        if (Duration < 0.0) throw new InvalidValueException("StartExposure", Duration.ToString(), "0.0 upwards");
        if (cameraNumX > ccdWidth) throw new InvalidValueException("StartExposure", cameraNumX.ToString(), ccdWidth.ToString());
        if (cameraNumY > ccdHeight) throw new InvalidValueException("StartExposure", cameraNumY.ToString(), ccdHeight.ToString());
        if (cameraStartX > ccdWidth) throw new InvalidValueException("StartExposure", cameraStartX.ToString(), ccdWidth.ToString());
        if (cameraStartY > ccdHeight) throw new InvalidValueException("StartExposure", cameraStartY.ToString(), ccdHeight.ToString());
        IsOnline = CheckConnection();
        if (!IsOnline)
        {
            tl.LogMessage("StartExposure", "disconnected");
            cameraState = CameraStates.cameraError;
            throw new ASCOM.NotConnectedException("StartExposure");
        }
        cameraImageReady = false;
        cameraState = CameraStates.cameraWaiting;
        if (Duration >= 30)
        {
            Duration = ((int)(Duration / 30)) * 30;
        }
        cameraLastExposureDuration = Duration;
        exposureStart = DateTime.Now;
        lastTimeStamp = GetTimeStamp();//记录开始的时间戳
        // 投递到专用 STA 相机线程执行采集，StartExposure 立即返回。
        // 所有 SDK 调用都在相机线程上（refresh/open/start 同一线程），避免 NOT_STARTED 和枚举失败。
        long gen = Interlocked.Increment(ref exposureGeneration);
        lock (imageLock)
        {
            currentFrame = null;
            captureDone = false;
        }

        PostToCameraThread(() =>
        {
            try
            {
                cameraConfig.stopexposure = false;
                ImageMatrix frame = (Duration >= 30)
                    ? cameraConfig.StartMultiExposure(Duration)
                    : cameraConfig.StartSingleExposure(Duration);

                lock (imageLock)
                {
                    // 仅当仍是当前代次的曝光时才提交结果，避免被 AbortExposure 或新曝光覆盖
                    if (gen == exposureGeneration)
                    {
                        currentFrame = frame;
                        captureDone = true;
                    }
                }
            }
            catch (Exception ex)
            {
                CameraLog.Write($"{DateTime.Now}: AsyncCapture ERROR {ex} callback\n");
                tl.LogMessage("StartExposure", "capture error: " + ex.Message);
                lock (imageLock)
                {
                    if (gen == exposureGeneration)
                    {
                        currentFrame = null;
                        captureDone = false;
                    }
                }
                cameraState = CameraStates.cameraError;
            }
        });
        tl.LogMessage("StartExposure", Duration.ToString() + " " + Light.ToString());
    }

    public int StartX
    {
        get
        {
            tl.LogMessage("StartX Get", cameraStartX.ToString());
            return cameraStartX;
        }
        set
        {
            // 仅支持全画幅（StartX 只能为 0），合法的 0 直接接受，非法值才抛异常
            if (value != 0)
                throw new ASCOM.InvalidValueException("StartX", value.ToString(), "subframe unsupported, only 0");
            cameraStartX = 0;
            tl.LogMessage("StartX Set", value.ToString());
        }
    }

    public int StartY
    {
        get
        {
            tl.LogMessage("StartY Get", cameraStartY.ToString());
            return cameraStartY;
        }
        set
        {
            // 仅支持全画幅（StartY 只能为 0），合法的 0 直接接受，非法值才抛异常
            if (value != 0)
                throw new ASCOM.InvalidValueException("StartY", value.ToString(), "subframe unsupported, only 0");
            cameraStartY = 0;
            tl.LogMessage("StartY set", value.ToString());
        }
    }

    public void StopExposure()
    {
        IsOnline = CheckConnection();
        if (!IsOnline)
        {
            tl.LogMessage("StopExposure", "disconnected");
            cameraState = CameraStates.cameraError;
            throw new ASCOM.NotConnectedException("StopExposure");
        }
        cameraConfig.stopexposure = true;
    }

    public string Action(string ActionName, string ActionParameters)
        => throw new ASCOM.ActionNotImplementedException("Action未实现");
    public void CommandBlind(string Command, bool Raw = false)
        => throw new ASCOM.MethodNotImplementedException("CommandBlind");
    public bool CommandBool(string Command, bool Raw = false)
    => throw new ASCOM.MethodNotImplementedException("CommandBool");
    public string CommandString(string Command, bool Raw = false)
    => throw new ASCOM.MethodNotImplementedException("CommandString");
    public void Dispose() {}
    public void Connect()
    {
        ConnectCamera(true);
    }

    public void Disconnect()
    {
        ConnectCamera(false);
    }

    public double SubExposureDuration
    {
        get
        {
            tl.LogMessage("SubExposureDuration Get", "Not implemented");
            throw new ASCOM.PropertyNotImplementedException("SubExposureDuration", false);
        }
        set
        {
            tl.LogMessage("SubExposureDuration Set", "Not implemented");
            throw new ASCOM.PropertyNotImplementedException("SubExposureDuration", true);
        }
    }

    public string Description => "ASCOM MyCamera Camera Driver";
    public string DriverInfo => "MyCameraDriver64";
    public string DriverVersion => "1.0";
    public short InterfaceVersion => 2;
    public string Name => "MyDo3Camera";
    public ArrayList SupportedActions => new ArrayList();
    //public bool Connecting => throw new System.NotImplementedException();
    public bool Connecting => throw new System.NotImplementedException();

    public bool Connected
    {
        get
        {
            LogMessage("Connected", "Get {0}", IsConnected);
            return IsConnected;
        }
        set
        {
            tl.LogMessage("Connected", "Set {0}", value);
            if (value == IsConnected)
                return;

            if (value)
            {
                ConnectCamera(true);
                LogMessage("Connected Set", "Connecting to port camera");
                // TODO connect to the device
            }
            else
            {
                ConnectCamera(false);
                LogMessage("Connected Set", "Disconnecting camera");
                // TODO disconnect from the device
            }
        }
    }

    private bool IsConnected
    {
        get
        {
            IsOnline = CheckConnection();
            connectedState = IsOnline;
            // TODO check that the driver hardware connection exists and is connected to the hardware
            return connectedState;
        }
    }

    internal void ReadProfile()
    {
        using (Profile driverProfile = new Profile())
        {
            driverProfile.DeviceType = "Camera";
            tl.Enabled = Convert.ToBoolean(driverProfile.GetValue(driverID, traceStateProfileName, string.Empty, traceStateDefault));
            comPort = driverProfile.GetValue(driverID, comPortProfileName, string.Empty, comPortDefault);
        }
    }

    internal void WriteProfile()
    {
        using (Profile driverProfile = new Profile())
        {
            driverProfile.DeviceType = "Camera";
            driverProfile.WriteValue(driverID, traceStateProfileName, tl.Enabled.ToString());
            driverProfile.WriteValue(driverID, comPortProfileName, comPort.ToString());
        }
    }

    public void SetupDialog()
    {
        if (IsConnected)
            System.Windows.Forms.MessageBox.Show("Already connected, just press OK");

        using (SetupDialogForm F = new SetupDialogForm(tl))
        {
            DialogResult result = F.ShowDialog();
            if (result == DialogResult.OK)
            {
                WriteProfile();
            }
        }
    }
    internal void LogMessage(string identifier, string message, params object[] args)
    {
        var msg = string.Format(message, args);
        tl.LogMessage(identifier, msg);
    }


    public IStateValueCollection DeviceState => throw new System.NotImplementedException();
    #endregion


    //ENDOFINSERTEDFILE
}