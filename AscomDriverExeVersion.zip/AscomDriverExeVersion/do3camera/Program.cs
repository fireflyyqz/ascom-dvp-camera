using DVPCameraType;
using MyCameraAPI;
using System;
using System.Globalization;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.IO.Pipes;
using System.Text;
using System.Threading;

namespace ConsoleApp3
{
    /// <summary>
    /// 相机服务进程（CameraServer）。
    /// 所有 DVP SDK 调用都在这个独立进程里执行，ASCOM 驱动通过：
    ///   1) 命名管道（Do3CameraServerPipe）发命令、收应答（文本行协议）
    ///   2) 共享内存（Do3CameraServerFrame）取图像帧
    /// 来与它交互。这样 SDK 始终运行在干净进程里，不受客户端（PHD2/NINA）进程影响。
    /// </summary>
    class Program
    {
        const string PipeName = "Do3CameraServerPipe";
        const string ShmName = "Do3CameraServerFrame";
        const int ShmHeaderBytes = 64;                              // 头部：ready/w/h/bits/ch
        const int MaxPixels = 4200 * 3200;                          // 略大于 4000x3000
        const int ShmSize = ShmHeaderBytes + MaxPixels * 4;         // int 像素，每像素4字节

        static uint cameraHandle = 0;
        static CameraConfig cameraConfig = null;
        static readonly CameraCapture camera = new CameraCapture();

        static MemoryMappedFile shm;
        static MemoryMappedViewAccessor shmView;

        static volatile bool captureDone = false;
        static Mutex serverMutex;   // 单实例守卫（进程存活期间一直持有）

        static void Main(string[] args)
        {
            // 单实例守卫：若已有服务在运行则直接退出。
            // 否则多个服务进程会同时抢同一个命名管道，刷屏报"所有的管道范例都在使用中"
            //（All pipe instances are busy）——驱动侧连接失败时会自动拉起服务，可能重复拉起。
            bool createdNew;
            serverMutex = new Mutex(true, "Do3CameraServerMutex", out createdNew);
            if (!createdNew)
            {
                Console.WriteLine("Another CameraServer is already running. Exiting.");
                return;
            }

            shm = MemoryMappedFile.CreateOrOpen(ShmName, ShmSize);
            shmView = shm.CreateViewAccessor(0, ShmSize);
            shmView.Write(0, 0);                                    // ready = 0

            Console.WriteLine("CameraServer started. Pipe=" + PipeName + " Shm=" + ShmName);

            // 自检模式：ConsoleApp3.exe selftest —— 不需要客户端，直接验证 SDK 能否连接+出图
            if (args.Length > 0 && args[0].Equals("selftest", StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("SELFTEST CONNECT: " + Handle("CONNECT"));
                Console.WriteLine("SELFTEST SETBIN : " + Handle("SETBIN 2"));
                Console.WriteLine("SELFTEST EXPOSE : " + Handle("EXPOSE 1000000"));
                for (int i = 0; i < 300 && Handle("READY") != "1"; i++) Thread.Sleep(100);
                Console.WriteLine("SELFTEST READY  : " + Handle("READY"));
                Console.WriteLine("SELFTEST GETFRAME: " + Handle("GETFRAME"));
                Console.WriteLine("SELFTEST finished.");
                return;
            }

            while (true)
            {
                try
                {
                    using (var pipe = new NamedPipeServerStream(PipeName, PipeDirection.InOut, 1))
                    {
                        pipe.WaitForConnection();
                        Console.WriteLine("Client connected.");
                        Serve(pipe);
                        Console.WriteLine("Client disconnected.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("accept error: " + ex.Message);
                    Thread.Sleep(500);
                }
            }
        }

        static void Serve(NamedPipeServerStream pipe)
        {
            var reader = new StreamReader(pipe, Encoding.ASCII);
            var writer = new StreamWriter(pipe, Encoding.ASCII) { AutoFlush = true };
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                string reply;
                try { reply = Handle(line.Trim()); }
                catch (Exception ex) { reply = "ERR " + ex.Message; Console.WriteLine("cmd error: " + ex); }
                writer.WriteLine(reply);
            }
        }

        static string Handle(string cmd)
        {
            if (cmd.Length == 0) return "ERR empty";
            string[] p = cmd.Split(' ');
            switch (p[0].ToUpperInvariant())
            {
                case "PING":         return "PONG";
                case "CONNECT":      return CmdConnect();
                case "DISCONNECT":   return CmdDisconnect();
                case "SETBIN":       return CmdSetBin(p);
                case "SETGAIN":      return CmdSetGain(p);
                case "GETGAINDESCR": return CmdGetGainDescr();
                case "GETEXPDESCR":  return CmdGetExpDescr();
                case "EXPOSE":       return CmdExpose(p);
                case "READY":        return captureDone ? "1" : "0";
                case "GETFRAME":     return CmdGetFrame();
                case "ABORT":        if (cameraConfig != null) cameraConfig.stopexposure = true; return "OK";
                case "QUIT":         Environment.Exit(0); return "OK";
                default:             return "ERR unknown cmd";
            }
        }

        static string CmdConnect()
        {
            if (cameraConfig != null) return "OK";

            uint count = 0;
            dvpStatus s = DVPCamera.dvpRefresh(ref count);
            Console.WriteLine("dvpRefresh: " + s + " count=" + count);
            if (s != dvpStatus.DVP_STATUS_OK) return "ERR refresh " + s;
            if (count == 0) return "ERR no device (count=0)";

            var info = new dvpCameraInfo();
            s = DVPCamera.dvpEnum(0, ref info);
            if (s != dvpStatus.DVP_STATUS_OK) return "ERR enum " + s;

            s = DVPCamera.dvpOpenByName(info.FriendlyName, dvpOpenMode.OPEN_NORMAL, ref cameraHandle);
            if (s != dvpStatus.DVP_STATUS_OK) return "ERR open " + s;

            cameraConfig = new CameraConfig(cameraHandle);
            cameraConfig.DefaultConfig();
            cameraConfig.SetResolutionModeSel(0);       // normal
            cameraConfig.SetSourceFormatSel(1);         // raw-12
            cameraConfig.SetTargetFormatSel(4);         // raw-16
            cameraConfig.SetExposureTime(1000000);
            Console.WriteLine("Connected to " + info.FriendlyName);
            return "OK";
        }

        static string CmdDisconnect()
        {
            if (cameraConfig == null) return "OK";
            cameraConfig.stopexposure = true;
            try { DVPCamera.dvpClose(cameraHandle); } catch (Exception) { }
            cameraConfig = null;
            cameraHandle = 0;
            captureDone = false;
            return "OK";
        }

        static string CmdSetBin(string[] p)
        {
            if (cameraConfig == null) return "ERR not connected";
            int bin = int.Parse(p[1], CultureInfo.InvariantCulture);
            uint mode = bin == 2 ? 1u : bin == 3 ? 3u : bin == 4 ? 5u : 0u;
            cameraConfig.SetResolutionModeSel(mode);
            return "OK";
        }

        static string CmdSetGain(string[] p)
        {
            if (cameraConfig == null) return "ERR not connected";
            float raw = float.Parse(p[1], CultureInfo.InvariantCulture);
            cameraConfig.SetGain(raw);
            return "OK";
        }

        static string CmdGetGainDescr()
        {
            if (cameraConfig == null) return "ERR not connected";
            var d = cameraConfig.GetGainDescr();
            return "OK " + Fmt(d.fMin) + " " + Fmt(d.fStep) + " " + Fmt(d.fMax);
        }

        static string CmdGetExpDescr()
        {
            if (cameraConfig == null) return "ERR not connected";
            var d = cameraConfig.GetExposureDescr();
            return "OK " + Fmt(d.fMin) + " " + Fmt(d.fStep) + " " + Fmt(d.fMax);
        }

        static string Fmt(double v) { return v.ToString(CultureInfo.InvariantCulture); }

        static string CmdExpose(string[] p)
        {
            if (cameraConfig == null) return "ERR not connected";
            double us = double.Parse(p[1], CultureInfo.InvariantCulture);

            captureDone = false;
            cameraConfig.stopexposure = false;

            var t = new Thread(() =>
            {
                try
                {
                    ImageMatrix frame = (us >= 30.0 * 1000000.0)
                        ? cameraConfig.StartMultiExposure(us / 1000000.0)
                        : cameraConfig.StartSingleExposure(us / 1000000.0);

                    if (frame != null && frame.Data2D != null)
                    {
                        WriteFrame(frame);
                        captureDone = true;
                    }
                }
                catch (Exception ex) { Console.WriteLine("capture error: " + ex); }
            });
            t.IsBackground = true;
            t.Start();
            return "OK";
        }

        // 把帧写进共享内存：头部 [ready][width][height][bits][channels]，之后是行优先 int 像素
        static void WriteFrame(ImageMatrix frame)
        {
            int w = frame.Width, h = frame.Height;
            shmView.Write(0, 0);                        // ready = 0（写入中）
            shmView.Write(4, w);
            shmView.Write(8, h);
            shmView.Write(12, frame.BitsPerPixel);
            shmView.Write(16, frame.Channels);

            int[] flat = new int[w * h];
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                    flat[y * w + x] = frame.Data2D[x, y];

            shmView.WriteArray(ShmHeaderBytes, flat, 0, flat.Length);
            shmView.Write(0, 1);                        // ready = 1
        }

        static string CmdGetFrame()
        {
            if (!captureDone) return "ERR not ready";
            int w = shmView.ReadInt32(4), h = shmView.ReadInt32(8);
            int bits = shmView.ReadInt32(12), ch = shmView.ReadInt32(16);
            return "OK " + w + " " + h + " " + bits + " " + ch;
        }
    }
}
